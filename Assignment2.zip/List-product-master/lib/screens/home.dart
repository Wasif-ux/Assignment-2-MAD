import 'package:flutter/material.dart';
import '../models/product.dart';
import 'details.dart';
class Home extends StatefulWidget {
  const Home({super.key});

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  // Create a list of products
  final List<Product> products = [
    Product(
      name: 'Shirt',
      image: 'assets/img.png',
      price: 1750,
      description: 'Stylish and Fashionable Shirt for Boys',
    ),
    Product(
      name: 'Trouser Pants',
      image: 'assets/img_1.png',
      price: 2200,
      description: 'A Pant fit for every Teen',
    ),
    Product(
      name: 'Silver Chain',
      image: 'assets/img_2.png',
      price: 3500,
      description: 'A Fashionable Accessory for Boys'),
    Product(
      name: 'leather Shoes',
      image: 'assets/img_3.png',
      price: 3700,
      description: 'Premium Quality Shoes for Man',
    )
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Men Store'),
        backgroundColor: Colors.blueGrey,
      ),
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 0.0),
          child: ListView.builder(
            itemCount: products.length,
            itemBuilder: (context, index) {
              Product product = products[index];
              return Card(
                child: ListTile(
                  leading: Image.asset(product.image),
                  title: Text(product.name),
                  subtitle: Text('\RS ${product.price}'),
                  onTap: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => Details(product: product),
                      ),
                    );
                  },
                ),
              );
            },
          ),
        ),
      ),
    );
  }
}
